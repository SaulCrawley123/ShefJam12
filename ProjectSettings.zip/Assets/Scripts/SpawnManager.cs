using UnityEngine;

public static class SpawnManager
{
    public static Vector2 spawnPosition;
    public static bool hasSpawnPosition = false;
}
